import cv2
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage,QPixmap

camera1ON=False
camera2On=False



def startWebcam(self) :
    self.capture = cv2.VideoCapture(1)
    self.capture.set(cv2.CAP_PROP_FRAME_WIDTH,640)
    self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
    self.timer = QTimer(self)
    self.timer.timeout.connect(self.updateFrame)
    self.timer.start(5)
def updateFrame(self) :
    ret,self.image = self.capture.read()
    self.image = cv2.flip(self.image,1)
    self.displayImage(self.image,1)
def displayImage(self,img,window = 1) :
    global camera2On,camera1ON
    self.image = cv2.cvtColor(self.image,cv2.COLOR_BGR2RGB)
    height, width, channel = self.image.shape
    bytesPerLine = 3 * width
    outImage = QImage(self.image.data, width, height, bytesPerLine, QImage.Format_RGB888)
    if window == 1 :
        if camera1ON :
            self.imgLabel.setPixmap(QPixmap.fromImage(outImage))
            self.imgLabel.setScaledContents(True)
        if camera2On:    
            self.imgLabel2.setPixmap(QPixmap.fromImage(outImage))
            self.imgLabel2.setScaledContents(True)      